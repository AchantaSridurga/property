package net.chrisrichardson.eventstore.examples.management.propertyservice.backend;


import io.eventuate.Command;

public interface PropertyCommand extends Command {
}
