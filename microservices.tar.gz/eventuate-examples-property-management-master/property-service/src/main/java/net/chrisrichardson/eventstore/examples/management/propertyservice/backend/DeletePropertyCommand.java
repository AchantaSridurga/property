package net.chrisrichardson.eventstore.examples.management.propertyservice.backend;

public class DeletePropertyCommand implements PropertyCommand {
}
