package net.chrisrichardson.eventstore.examples.management.property.common.event;

public class PropertyDeletedEvent extends PropertyEvent {
}
