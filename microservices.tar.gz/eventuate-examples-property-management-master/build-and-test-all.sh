#! /bin/bash

./_build-and-test-all.sh $*
